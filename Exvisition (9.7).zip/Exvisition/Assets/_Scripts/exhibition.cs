﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class exhibition : MonoBehaviour {

	// Use this for initialization
	IEnumerator Start() {
		string url = string.Concat("http://127.0.0.1/exvisition/exhibition.php?eid=", listExhibition.eid);
		print(url);
		WWW www = new WWW(url);
		yield return www;

		string[] member;
		member = www.text.Split(';');
		this.GetComponent<Text>().text = member[1];
	}
}